/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 breakout breakout.png 
 * Time-stamp: Wednesday 04/01/2020, 03:34:43
 * 
 * Image Information
 * -----------------
 * breakout.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BREAKOUT_H
#define BREAKOUT_H

extern const unsigned short breakout[38400];
#define BREAKOUT_SIZE 76800
#define BREAKOUT_LENGTH 38400
#define BREAKOUT_WIDTH 240
#define BREAKOUT_HEIGHT 160

#endif


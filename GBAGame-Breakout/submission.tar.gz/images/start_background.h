/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 start_background start_background.png 
 * Time-stamp: Wednesday 04/01/2020, 23:31:59
 * 
 * Image Information
 * -----------------
 * start_background.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef START_BACKGROUND_H
#define START_BACKGROUND_H

extern const unsigned short start_background[38400];
#define START_BACKGROUND_SIZE 76800
#define START_BACKGROUND_LENGTH 38400
#define START_BACKGROUND_WIDTH 240
#define START_BACKGROUND_HEIGHT 160

#endif


/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 white_ball white-ball.png 
 * Time-stamp: Thursday 04/02/2020, 19:02:21
 * 
 * Image Information
 * -----------------
 * white-ball.png 2@2
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#include "white_ball.h"

const unsigned short whiteball[4] =
{
	0x7fff,0x77bd,0x7fff,0x7fff
};


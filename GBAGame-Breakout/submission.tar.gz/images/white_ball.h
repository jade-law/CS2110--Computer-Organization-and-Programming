/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 white_ball white-ball.png 
 * Time-stamp: Thursday 04/02/2020, 19:02:21
 * 
 * Image Information
 * -----------------
 * white-ball.png 2@2
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WHITE_BALL_H
#define WHITE_BALL_H

extern const unsigned short whiteball[4];
#define WHITEBALL_SIZE 8
#define WHITEBALL_LENGTH 4
#define WHITEBALL_WIDTH 2
#define WHITEBALL_HEIGHT 2

#endif


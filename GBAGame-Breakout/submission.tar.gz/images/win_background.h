/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 win_background win_background.png 
 * Time-stamp: Wednesday 04/01/2020, 23:34:16
 * 
 * Image Information
 * -----------------
 * win_background.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef WIN_BACKGROUND_H
#define WIN_BACKGROUND_H

extern const unsigned short win_background[38400];
#define WIN_BACKGROUND_SIZE 76800
#define WIN_BACKGROUND_LENGTH 38400
#define WIN_BACKGROUND_WIDTH 240
#define WIN_BACKGROUND_HEIGHT 160

#endif


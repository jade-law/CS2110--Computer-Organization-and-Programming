This is the classic Breakout Game.
Use the return button on the start screen, win screen or lose screen to play/replay the game.
Use the delete button to return to the start screen at any time.
Use the left and right arrow keys to control the paddle during the game.
Hit the white ball with the paddle to hit the colorful bricks at the top of the screen.
    - Red bricks: 5 points
    - Yellow bricks: 4 points
    - Green bricks: 3 points
    - Cyan bricks: 2 points
    - Blue bricks: 1 point
If the white ball falls past the paddle and off the screen, you lose.
If all the bricks are cleared, you win.
Enjoy!